package com.portafolio.carlosmarcano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarlosmarcanoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarlosmarcanoApplication.class, args);
	}

}
