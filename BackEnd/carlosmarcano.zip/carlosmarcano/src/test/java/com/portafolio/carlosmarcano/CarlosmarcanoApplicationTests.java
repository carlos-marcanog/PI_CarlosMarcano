package com.portafolio.carlosmarcano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarlosmarcanoApplicationTests {

	@Test
	void contextLoads() {
	}

}
